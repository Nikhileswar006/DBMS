import os
import secrets
from datetime import date
from decimal import Decimal, InvalidOperation

from flask import Flask, render_template, request, redirect, url_for, flash
import psycopg2
from psycopg2.extras import RealDictCursor


app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY") or secrets.token_hex(32)


# =========================================================
# DATABASE CONFIGURATION
# =========================================================

DB_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": int(os.environ.get("DB_PORT", "5432")),
    "database": os.environ.get("DB_NAME", "smart_student_study_planner"),
    "user": os.environ.get("DB_USER", "postgres"),
    "password": os.environ.get("DB_PASSWORD", os.environ.get("PGPASSWORD", "909090")),
}


def get_db_connection():
    return psycopg2.connect(**DB_CONFIG)


def query_all(sql, params=()):
    conn = get_db_connection()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, params)
            return cur.fetchall()
    finally:
        conn.close()


def query_one(sql, params=()):
    rows = query_all(sql, params)
    return rows[0] if rows else None


def execute_sql(sql, params=()):
    conn = get_db_connection()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchone() if cur.description else None
    finally:
        conn.close()


def form_value(name):
    """Return a trimmed form value, or None when blank."""
    value = request.form.get(name, "").strip()
    return value if value else None


def as_int(value, field_name, required=False):
    if value is None or value == "":
        if required:
            raise ValueError(f"{field_name} is required.")
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} must be a valid whole number.")


def as_decimal(value, field_name, required=False):
    if value is None or value == "":
        if required:
            raise ValueError(f"{field_name} is required.")
        return None
    try:
        number = Decimal(value)
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError(f"{field_name} must be a valid number.")
    if not number.is_finite():
        raise ValueError(f"{field_name} must be a finite number.")
    return number


def safe_error_message(exc, fallback):
    return str(exc) if isinstance(exc, ValueError) else fallback


def redirect_with_flash(endpoint, message, category="success"):
    flash(message, category)
    return redirect(url_for(endpoint))


# =========================================================
# DASHBOARD
# =========================================================

@app.route("/")
def index():
    try:
        counts = {
            "students": query_one("SELECT COUNT(*) AS total FROM students")["total"],
            "subjects": query_one("SELECT COUNT(*) AS total FROM subjects")["total"],
            "topics": query_one("SELECT COUNT(*) AS total FROM topics")["total"],
            "study_plan": query_one("SELECT COUNT(*) AS total FROM study_plan")["total"],
            "study_log": query_one("SELECT COUNT(*) AS total FROM study_log")["total"],
            "exams": query_one("SELECT COUNT(*) AS total FROM exams")["total"],
            "reminders": query_one("SELECT COUNT(*) AS total FROM reminders")["total"],
        }

        upcoming_exams = query_all("""
            SELECT e.exam_id, e.exam_name, e.exam_date, e.exam_time,
                   s.subject_name, st.name AS student_name
            FROM exams e
            JOIN subjects s ON s.subject_id = e.subject_id
            JOIN students st ON st.student_id = e.student_id
            WHERE e.exam_date >= CURRENT_DATE
            ORDER BY e.exam_date, e.exam_time NULLS LAST
            LIMIT 5
        """)

        return render_template(
            "index.html",
            counts=counts,
            student_count=counts["students"],
            subject_count=counts["subjects"],
            topic_count=counts["topics"],
            study_plan_count=counts["study_plan"],
            study_log_count=counts["study_log"],
            exam_count=counts["exams"],
            reminder_count=counts["reminders"],
            upcoming_exams=upcoming_exams,
        )
    except Exception as exc:
        app.logger.exception("Dashboard loading failed")
        return "Unable to load the dashboard. Please try again later.", 500


# =========================================================
# STUDENTS CRUD
# =========================================================

@app.route("/students")
def students():
    try:
        data = query_all("""
            SELECT student_id, name, email
            FROM students
            ORDER BY student_id
        """)
        return render_template("students.html", students=data)
    except Exception as exc:
        app.logger.exception("Loading students failed")
        return "Unable to load students. Please try again later.", 500


@app.route("/students/add", methods=["POST"])
def add_student():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()

    if not name or not email:
        return redirect_with_flash("students", "Name and email are required.", "danger")

    try:
        execute_sql(
            "INSERT INTO students (name, email) VALUES (%s, %s)",
            (name, email),
        )
        return redirect_with_flash("students", "Student added successfully.")
    except psycopg2.errors.UniqueViolation:
        return redirect_with_flash("students", "This email already exists.", "danger")
    except Exception as exc:
        app.logger.exception("Adding student failed")
        return redirect_with_flash(
            "students", "Unable to add student. Please try again.", "danger"
        )


@app.route("/students/update/<int:student_id>", methods=["POST"])
def update_student(student_id):
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()

    if not name or not email:
        return redirect_with_flash("students", "Name and email are required.", "danger")

    try:
        execute_sql(
            "UPDATE students SET name = %s, email = %s WHERE student_id = %s",
            (name, email, student_id),
        )
        return redirect_with_flash("students", "Student updated successfully.")
    except psycopg2.errors.UniqueViolation:
        return redirect_with_flash("students", "That email belongs to another student.", "danger")
    except Exception as exc:
        app.logger.exception("Updating student failed")
        return redirect_with_flash(
            "students", "Unable to update student. Please try again.", "danger"
        )


@app.route("/students/delete/<int:student_id>", methods=["POST"])
def delete_student(student_id):
    try:
        execute_sql("DELETE FROM students WHERE student_id = %s", (student_id,))
        return redirect_with_flash(
            "students",
            "Student deleted. Related records may also have been deleted by database cascades.",
        )
    except Exception as exc:
        app.logger.exception("Deleting student failed")
        return redirect_with_flash(
            "students", "Unable to delete student. Please try again.", "danger"
        )


# =========================================================
# SUBJECTS CRUD
# =========================================================

@app.route("/subjects")
def subjects():
    try:
        subjects_data = query_all("""
            SELECT s.subject_id, s.subject_name, s.description, s.credits,
                   STRING_AGG(st.name, ', ' ORDER BY st.name) AS student_names
            FROM subjects s
            LEFT JOIN student_subject ss ON ss.subject_id = s.subject_id
            LEFT JOIN students st ON st.student_id = ss.student_id
            GROUP BY s.subject_id, s.subject_name, s.description, s.credits
            ORDER BY s.subject_id
        """)
        students_data = query_all("""
            SELECT student_id, name, email
            FROM students
            ORDER BY name
        """)
        return render_template(
            "subjects.html",
            subjects=subjects_data,
            students=students_data,
        )
    except Exception as exc:
        app.logger.exception("Loading subjects failed")
        return "Unable to load subjects. Please try again later.", 500


def save_subject(subject_id=None):
    name = request.form.get("subject_name", "").strip()
    description = form_value("description")
    credits_text = form_value("credits")
    student_ids = list(dict.fromkeys(request.form.getlist("student_ids")))
    single_student = form_value("student_id")
    if single_student:
        student_ids.append(single_student)
        student_ids = list(dict.fromkeys(student_ids))

    if not name:
        raise ValueError("Subject name is required.")

    credits = as_int(credits_text, "Credits")
    if credits is not None and credits <= 0:
        raise ValueError("Credits must be greater than zero.")

    valid_student_ids = []
    for student_id in student_ids:
        parsed_id = as_int(student_id, "Student ID", required=True)
        valid_student_ids.append(parsed_id)

    conn = get_db_connection()
    try:
        with conn:
            with conn.cursor() as cur:
                if subject_id is None:
                    cur.execute("""
                        INSERT INTO subjects (subject_name, description, credits)
                        VALUES (%s, %s, %s)
                        RETURNING subject_id
                    """, (name, description, credits))
                    saved_subject_id = cur.fetchone()[0]
                else:
                    cur.execute("""
                        UPDATE subjects
                        SET subject_name = %s, description = %s, credits = %s
                        WHERE subject_id = %s
                    """, (name, description, credits, subject_id))
                    if cur.rowcount == 0:
                        raise ValueError("Subject not found.")
                    saved_subject_id = subject_id

                cur.execute(
                    "DELETE FROM student_subject WHERE subject_id = %s",
                    (saved_subject_id,),
                )
                for student_id in valid_student_ids:
                    cur.execute("""
                        INSERT INTO student_subject (student_id, subject_id)
                        VALUES (%s, %s)
                        ON CONFLICT DO NOTHING
                    """, (student_id, saved_subject_id))
    finally:
        conn.close()


@app.route("/subjects/add", methods=["POST"])
def add_subject():
    try:
        save_subject()
        return redirect_with_flash("subjects", "Subject added successfully.")
    except Exception as exc:
        app.logger.exception("Adding subject failed")
        return redirect_with_flash(
            "subjects", safe_error_message(exc, "Unable to add subject. Please try again."),
            "danger",
        )


@app.route("/subjects/update/<int:subject_id>", methods=["POST"])
def update_subject(subject_id):
    try:
        save_subject(subject_id)
        return redirect_with_flash("subjects", "Subject updated successfully.")
    except Exception as exc:
        app.logger.exception("Updating subject failed")
        return redirect_with_flash(
            "subjects", safe_error_message(exc, "Unable to update subject. Please try again."),
            "danger",
        )


@app.route("/subjects/delete/<int:subject_id>", methods=["POST"])
def delete_subject(subject_id):
    try:
        execute_sql("DELETE FROM subjects WHERE subject_id = %s", (subject_id,))
        return redirect_with_flash("subjects", "Subject deleted successfully.")
    except Exception as exc:
        app.logger.exception("Deleting subject failed")
        return redirect_with_flash(
            "subjects", "Unable to delete subject. Please try again.", "danger"
        )


# =========================================================
# CONFIGURATION FOR THE FIVE REMAINING MODULES
# =========================================================

MODULES = {
    "topics": {
        "title": "Topics",
        "table": "topics",
        "pk": "topic_id",
        "template": "topics.html",
        "fields": ["topic_name", "description", "subject_id"],
    },
    "study-plans": {
        "title": "Study Plans",
        "table": "study_plan",
        "pk": "study_plan_id",
        "template": "study_plans.html",
        "fields": ["student_id", "plan_name", "start_date", "end_date", "status"],
    },
    "study-logs": {
        "title": "Study Logs",
        "table": "study_log",
        "pk": "study_log_id",
        "template": "study_logs.html",
        "fields": ["topic_id", "study_date", "duration_minutes", "notes"],
    },
    "exams": {
        "title": "Exams",
        "table": "exams",
        "pk": "exam_id",
        "template": "exams.html",
        "fields": [
            "student_id", "subject_id", "exam_name", "exam_date",
            "exam_time", "total_marks", "marks_obtained",
        ],
    },
    "reminders": {
        "title": "Reminders",
        "table": "reminders",
        "pk": "reminder_id",
        "template": "reminders.html",
        "fields": [
            "study_plan_id", "title", "reminder_date",
            "reminder_time", "is_completed",
        ],
    },
}


# =========================================================
# MODULE DATA QUERIES
# =========================================================

def get_module_data(slug):
    if slug == "topics":
        return {
            "topics": query_all("""
                SELECT t.topic_id, t.topic_name, t.description,
                       t.subject_id, s.subject_name
                FROM topics t
                JOIN subjects s ON s.subject_id = t.subject_id
                ORDER BY t.topic_id DESC
            """),
            "subjects": query_all("""
                SELECT subject_id, subject_name
                FROM subjects ORDER BY subject_name
            """),
        }

    if slug == "study-plans":
        return {
            "study_plans": query_all("""
                SELECT sp.study_plan_id, sp.student_id, st.name AS student_name,
                       sp.plan_name, sp.start_date, sp.end_date, sp.status
                FROM study_plan sp
                JOIN students st ON st.student_id = sp.student_id
                ORDER BY sp.study_plan_id DESC
            """),
            "students": query_all("""
                SELECT student_id, name, email
                FROM students ORDER BY name
            """),
        }

    if slug == "study-logs":
        return {
            "study_logs": query_all("""
                SELECT sl.study_log_id, sl.topic_id, t.topic_name,
                       s.subject_name, sl.study_date,
                       sl.duration_minutes, sl.notes
                FROM study_log sl
                JOIN topics t ON t.topic_id = sl.topic_id
                JOIN subjects s ON s.subject_id = t.subject_id
                ORDER BY sl.study_date DESC, sl.study_log_id DESC
            """),
            "topics": query_all("""
                SELECT t.topic_id, t.topic_name, s.subject_name
                FROM topics t
                JOIN subjects s ON s.subject_id = t.subject_id
                ORDER BY s.subject_name, t.topic_name
            """),
        }

    if slug == "exams":
        return {
            "exams": query_all("""
                SELECT e.exam_id, e.student_id, e.subject_id,
                       e.exam_name, e.exam_date, e.exam_time,
                       e.total_marks, e.marks_obtained,
                       st.name AS student_name, s.subject_name
                FROM exams e
                JOIN students st ON st.student_id = e.student_id
                JOIN subjects s ON s.subject_id = e.subject_id
                ORDER BY e.exam_date DESC, e.exam_id DESC
            """),
            "students": query_all("""
                SELECT student_id, name FROM students ORDER BY name
            """),
            "subjects": query_all("""
                SELECT subject_id, subject_name FROM subjects ORDER BY subject_name
            """),
        }

    if slug == "reminders":
        return {
            "reminders": query_all("""
                SELECT r.reminder_id, r.study_plan_id, r.title,
                       r.reminder_date, r.reminder_time, r.is_completed,
                       sp.plan_name, st.name AS student_name
                FROM reminders r
                JOIN study_plan sp ON sp.study_plan_id = r.study_plan_id
                JOIN students st ON st.student_id = sp.student_id
                ORDER BY r.reminder_date, r.reminder_time NULLS LAST, r.reminder_id DESC
            """),
            "study_plans": query_all("""
                SELECT sp.study_plan_id, sp.plan_name, st.name AS student_name
                FROM study_plan sp
                JOIN students st ON st.student_id = sp.student_id
                ORDER BY sp.plan_name
            """),
        }

    raise ValueError("Unknown module.")


# =========================================================
# MODULE FORM VALIDATION AND SAVE
# =========================================================

def module_form_values(slug):
    values = {}

    for field in MODULES[slug]["fields"]:
        raw = request.form.get(field, "").strip()

        if field == "is_completed":
            values[field] = raw.lower() in ("true", "1", "on", "yes")
            continue

        if raw == "":
            values[field] = None
        else:
            values[field] = raw

    required_fields = {
        "topics": ["topic_name", "subject_id"],
        "study-plans": ["student_id", "plan_name", "start_date", "status"],
        "study-logs": ["topic_id", "study_date", "duration_minutes"],
        "exams": ["student_id", "subject_id", "exam_name", "exam_date"],
        "reminders": ["study_plan_id", "title", "reminder_date"],
    }[slug]

    for field in required_fields:
        if values.get(field) is None:
            raise ValueError(f"{field.replace('_', ' ').title()} is required.")

    for field in ("student_id", "subject_id", "topic_id", "study_plan_id"):
        if field in values and values[field] is not None:
            values[field] = as_int(values[field], field.replace("_", " ").title(), True)

    if "duration_minutes" in values:
        values["duration_minutes"] = as_int(
            values["duration_minutes"], "Duration in minutes", required=True
        )
        if values["duration_minutes"] <= 0:
            raise ValueError("Duration must be greater than zero.")

    if slug == "study-plans":
        if values["status"] not in ("Pending", "In Progress", "Completed", "On Hold"):
            raise ValueError("Choose a valid study plan status.")
        if values["end_date"] and values["end_date"] < values["start_date"]:
            raise ValueError("End date cannot be earlier than start date.")

    if slug == "exams":
        values["total_marks"] = as_decimal(values["total_marks"], "Total marks")
        values["marks_obtained"] = as_decimal(values["marks_obtained"], "Marks obtained")
        if values["total_marks"] is not None and values["total_marks"] <= 0:
            raise ValueError("Total marks must be greater than zero.")
        if values["marks_obtained"] is not None and values["marks_obtained"] < 0:
            raise ValueError("Marks obtained cannot be negative.")
        if (
            values["total_marks"] is not None
            and values["marks_obtained"] is not None
            and values["marks_obtained"] > values["total_marks"]
        ):
            raise ValueError("Marks obtained cannot exceed total marks.")

    return values


def save_module_record(slug, record_id=None):
    cfg = MODULES[slug]
    values = module_form_values(slug)

    fields = list(values.keys())
    params = [values[field] for field in fields]

    if record_id is None:
        columns = ", ".join(fields)
        placeholders = ", ".join(["%s"] * len(fields))
        execute_sql(
            f"INSERT INTO {cfg['table']} ({columns}) VALUES ({placeholders})",
            tuple(params),
        )
        flash(f"{cfg['title']} record added successfully.", "success")
    else:
        assignments = ", ".join(f"{field} = %s" for field in fields)
        execute_sql(
            f"UPDATE {cfg['table']} SET {assignments} WHERE {cfg['pk']} = %s",
            tuple(params + [record_id]),
        )
        flash(f"{cfg['title']} record updated successfully.", "success")


# =========================================================
# SHARED ROUTE FOR TOPICS, PLANS, LOGS, EXAMS, REMINDERS
# =========================================================

@app.route("/<slug>", methods=["GET", "POST"])
def module_page(slug):
    if slug not in MODULES:
        return "Page not found", 404

    cfg = MODULES[slug]

    try:
        if request.method == "POST":
            try:
                if request.form.get("delete_id"):
                    record_id = as_int(request.form.get("delete_id"), "Record ID", True)
                    execute_sql(
                        f"DELETE FROM {cfg['table']} WHERE {cfg['pk']} = %s",
                        (record_id,),
                    )
                    flash(f"{cfg['title']} record deleted successfully.", "success")

                elif slug == "reminders" and request.form.get("toggle_id"):
                    reminder_id = as_int(
                        request.form.get("toggle_id"), "Reminder ID", True
                    )
                    execute_sql("""
                        UPDATE reminders
                        SET is_completed = NOT is_completed
                        WHERE reminder_id = %s
                    """, (reminder_id,))
                    flash("Reminder status updated.", "success")

                elif request.form.get("edit_id"):
                    record_id = as_int(request.form.get("edit_id"), "Record ID", True)
                    save_module_record(slug, record_id)

                else:
                    save_module_record(slug)

            except Exception as exc:
                app.logger.exception("Saving %s failed", slug)
                flash(
                    safe_error_message(
                        exc,
                        f"Unable to process {cfg['title'].lower()}. Please try again.",
                    ),
                    "danger",
                )

            return redirect(url_for("module_page", slug=slug))

        data = get_module_data(slug)
        data["current_date"] = date.today().isoformat()
        return render_template(cfg["template"], **data)

    except Exception as exc:
        app.logger.exception("Loading %s failed", slug)
        return f"Unable to load {cfg['title'].lower()}. Please try again later.", 500


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":
    debug_enabled = os.environ.get("FLASK_DEBUG", "").strip().lower() in {
        "1", "true", "yes",
    }
    app.run(debug=debug_enabled)
